# Shizuku Optimizer for Codemagic
Build this project using Codemagic to get your APK.